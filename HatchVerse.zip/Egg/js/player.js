export const player = {
    coins: 500,
    gems: 0,

    // Инвентарь
    pets: [],

    // Надетые питомцы (массив petId)
    equipped: []
};