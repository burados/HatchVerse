import { player } from "./player.js";
import { hatchStarterEgg, starterEgg } from "./eggs.js";

// ---------- Navigation ----------
const screens = document.querySelectorAll(".screen");
const navButtons = document.querySelectorAll(".nav-btn");

navButtons.forEach(button => {

    button.addEventListener("click", () => {

        screens.forEach(screen =>
            screen.classList.remove("active-screen")
        );

        navButtons.forEach(btn =>
            btn.classList.remove("active")
        );

        document
            .getElementById(button.dataset.screen)
            .classList.add("active-screen");

        button.classList.add("active");

        updateUI();

    });

});

// ---------- UI ----------
const coinsText = document.getElementById("coins");
const gemsText = document.getElementById("gems");
const incomeText = document.getElementById("income");

const openEggBtn = document.getElementById("openEggBtn");

const petsList = document.getElementById("petsList");
const equipSlots = document.getElementById("equipSlots");

const popup = document.getElementById("petPopup");
const popupName = document.getElementById("popupPetName");
const popupRarity = document.getElementById("popupPetRarity");
const popupIncome = document.getElementById("popupPetIncome");
const closePopup = document.getElementById("closePopup");

// ---------- Popup ----------

closePopup.addEventListener("click", () => {

    popup.classList.add("hidden");

});

// ---------- Income ----------

function getIncome(){

    let total = 0;

    player.equipped.forEach(pet=>{

        total += pet.income;

    });

    return total;

}

// ---------- UI ----------

function updateUI(){

    coinsText.textContent = Math.floor(player.coins);

    gemsText.textContent = player.gems;

    incomeText.textContent = getIncome() + "/sec";

    // Equip Slots

    equipSlots.innerHTML="";

    for(let i=0;i<5;i++){

        const slot=document.createElement("div");

        slot.className="slot";

        if(player.equipped[i]){

            slot.textContent="🐾";

        }

        equipSlots.appendChild(slot);

    }

    // Pets

    petsList.innerHTML="";

    player.pets.forEach((pet,index)=>{

        const card=document.createElement("div");

        card.className="pet-card";

        card.innerHTML=`
            <div class="pet-name">${pet.name}</div>
            <div class="pet-info">
                ${pet.rarity}<br>
                +${pet.income}/sec<br>
                x${pet.amount}
            </div>
        `;

        card.onclick=()=>{

            if(player.equipped.includes(pet)){

                return;

            }

            if(player.equipped.length>=5){

                alert("Maximum equipped pets!");

                return;

            }

            player.equipped.push(pet);

            updateUI();

        };

        petsList.appendChild(card);

    });

}

updateUI();

// ---------- Coins ----------

setInterval(()=>{

    player.coins += getIncome();

    updateUI();

},1000);

// ---------- Egg ----------

openEggBtn.addEventListener("click",()=>{

    if(player.coins<starterEgg.price){

        alert("Not enough coins!");

        return;

    }

    player.coins-=starterEgg.price;

    const pet=hatchStarterEgg();

    const existingPet = player.pets.find(p => p.id === pet.id);

if (existingPet) {
    existingPet.amount++;
} else {
    player.pets.push({
        ...pet,
        amount: 1
    });
}

    popupName.textContent=pet.name;

    popupRarity.textContent=pet.rarity;

    popupIncome.textContent="+"+pet.income+" Coin/sec";

    popup.classList.remove("hidden");

    updateUI();

});