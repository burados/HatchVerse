import { player } from "./player.js";

const SAVE_KEY = "hatchverse_save";

export function saveGame() {

    localStorage.setItem(
        SAVE_KEY,
        JSON.stringify(player)
    );

}

export function loadGame() {

    const data = localStorage.getItem(SAVE_KEY);

    if (!data) return;

    const save = JSON.parse(data);

    Object.assign(player, save);

}